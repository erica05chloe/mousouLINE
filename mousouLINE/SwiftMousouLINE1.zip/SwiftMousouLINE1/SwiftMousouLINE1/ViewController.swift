//
//  ViewController.swift
//  SwiftMousouLINE1
//
//  Created by Yuta Fujii on 2016/08/28.
//  Copyright © 2016年 Yuta Fujii. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    
    }


}

